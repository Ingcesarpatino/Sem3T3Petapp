package com.dragonartgames.s3c3petapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<Mascotas> mascotas;
    private RecyclerView listarv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listarv = (RecyclerView) findViewById(R.id.rvMascotsa);
        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setOrientation(LinearLayoutManager.VERTICAL);

        listarv.setLayoutManager(llm);

        inicializarListaMascotas();
        inicializarAddaptador();
    }
    public void inicializarAddaptador(){
        MascotasAdaptador adaptador = new MascotasAdaptador(mascotas);
        listarv.setAdapter(adaptador);
    }
    public void inicializarListaMascotas(){

        mascotas = new ArrayList<Mascotas>();

        mascotas.add(new Mascotas("BRUNO","0",R.drawable.perro1));
        mascotas.add(new Mascotas("LUNA", "0", R.drawable.gato2));
        mascotas.add(new Mascotas("RUFO", "0", R.drawable.perro3));
        mascotas.add(new Mascotas("FIGO", "0", R.drawable.perro4));
        mascotas.add(new Mascotas("KIRA", "0", R.drawable.gat05));
    }

    public void mascofavoritas (View view){
       Intent intent = new Intent(MainActivity.this, MascotasFav.class  );
       startActivity(intent);
    }


}