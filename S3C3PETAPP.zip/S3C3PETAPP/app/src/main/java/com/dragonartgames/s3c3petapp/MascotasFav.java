package com.dragonartgames.s3c3petapp;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class MascotasFav  extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mascotasfavoritas);

    }
}
