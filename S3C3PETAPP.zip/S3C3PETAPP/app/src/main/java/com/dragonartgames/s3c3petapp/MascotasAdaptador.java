package com.dragonartgames.s3c3petapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MascotasAdaptador extends RecyclerView.Adapter<MascotasAdaptador.MascotasViewHolder> {

    ArrayList<Mascotas> mascota;

    public MascotasAdaptador(ArrayList<Mascotas>mascota){

        this.mascota = mascota;

    }

    @NonNull
    @Override
    public MascotasViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

       View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.cardview_mascotas,parent, false);

       return new MascotasViewHolder (v);



    }

    @Override
    public void onBindViewHolder(@NonNull final MascotasViewHolder mascotasViewHolder, int position) {
        final Mascotas masco = mascota.get(position);

        mascotasViewHolder.imgFoto.setImageResource(masco.getFoto());
        mascotasViewHolder.tvNombre.setText(masco.getNombre());
        mascotasViewHolder.tvContador.setText(masco.getContador());

        mascotasViewHolder.btnLike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    int lk = 0;
                    lk = lk + 1;
                    mascotasViewHolder.tvContador.setText(""+lk);

            }
        });



    }

    @Override
    public int getItemCount() {

        return mascota.size();
    }

    public static class MascotasViewHolder extends RecyclerView.ViewHolder{

        private ImageView imgFoto;
        private ImageButton btnLike;
        private TextView tvNombre;
        private TextView tvContador;
        public MascotasViewHolder(@NonNull View itemView) {
            super(itemView);

            imgFoto = (ImageView) itemView.findViewById(R.id.imgFoto);
            btnLike = (ImageButton) itemView.findViewById(R.id.btnLike);
            tvNombre = (TextView) itemView.findViewById(R.id.tvNombre);
            tvContador = (TextView) itemView.findViewById(R.id.tvContador);


        }
    }


}
